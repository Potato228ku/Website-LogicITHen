@echo off
title Calculator
:start
set /p expression=Enter the expression to calculate: 
set /a ans=%expression%
echo.
echo = %ans%
echo.
pause
cls
goto start