@echo off
title Stopwatch
setlocal enabledelayedexpansion

set /a seconds=0

:loop
cls
echo Stopwatch: !seconds! seconds
set /a seconds+=1
ping -n 2 127.0.0.1 >nul
goto loop