@echo off
title Stopwatch
setlocal enabledelayedexpansion

set /a seconds=0

:loop
cls
echo Stopwatch: !seconds! seconds
set /a seconds+=1
timeout /t 1 /nobreak >nul
goto loop