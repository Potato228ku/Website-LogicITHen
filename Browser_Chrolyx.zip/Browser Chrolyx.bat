@echo off
title Browser Chrolyx
chcp 866 >nul

: Start
cls
set /p url=Enter URL: 
powershell -command "$content = (Invoke-webRequest -Uri '%url%').Content; $content -replace '<[^>]+>', ''"
pause
goto Start